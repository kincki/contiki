#ifndef ANUMBER_H
#define ANUMBER_H

unsigned short get_number(void);

#endif // ANUMBER_H
